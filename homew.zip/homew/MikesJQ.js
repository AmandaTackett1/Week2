$(document).ready(function(){
$( ".container li" ).append( "<li>list item</li>" );
});